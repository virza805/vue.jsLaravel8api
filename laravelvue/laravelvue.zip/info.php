<?php

# composer create-project --prefer-dist laravel/laravel:^7.0 laravelvue|=>
# cd laravelvue
# composer require laravel/ui:^2.4 |=> for UI & UX
# php artisan ui bootstrap |=>
# php artisan ui vue |=>
# npm install |=>
/*
.htaccess
<Files .env>
Order deny,allow
Deny from all
</Files>
*/

# npm install vue-router |=>
# npm i --save axios |=> # npm install form-data |=> for upload image & controlle from Data
#  |=>
#  |=>
# php artisan make:model Employee -mc |  php artisan migrate |=>
#  |=>
# npm i --save v-toaster |=> https://www.npmjs.com/package/v-toaster
#  |=>
# npm install sweetalert2 |=> https://sweetalert2.github.io/#download
#  |=>
# # # |=> Laravel Sanctum Authentication <=| # # #
#  |=> https://router.vuejs.org/guide/advanced/meta.html
# php artisan make:controller AuthController |=>
#  |=>
#  |=>
# composer require laravel/sanctum |=>
# php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider" |=>
# php artisan migrate |=> php artisan migrate:fresh
# app/Http/Kernel.php file:

# use Laravel\Sanctum\Http\Middleware\EnsureFrontendRequestsAreStateful; |=>
#  |=>
#  |=>
#  |=> ib-ktrV8ED8
#  |=>







