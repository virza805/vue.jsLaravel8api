<template>
    <v-container fluid class="promo">
        <v-content>
            <div class="text-center" style="margin-top:13%">
                <h2 class="display-2">
                    <a href="https://www.tesla.com/modelx" target="_blank" rel="noopener noreferrer">Go Electric</a>
                </h2>
                <h2 class="display-1">
                    Save The Planet
                </h2>
            </div>
        </v-content>
    </v-container>
</template>
<script>
export default {
    
}
</script>
<style>
    .promo{
        background: url('https://tesla-cdn.thron.com/delivery/public/image/tesla/da705069-91b5-41cb-86f3-86a585c6fdf3/bvlatuR/std/2880x1800/MX-Hero-Desktop');
        background-size: cover;
        width: 100%;
        height: 100vh; 
    }
</style>