<template>
    <div>
        <promo />
        <specifications />
    </div>
  
  
</template>

<script>
import Promo from '../components/Promo.vue'
import Specifications from '../components/Specifications.vue'
 // @ is an alias to /src

export default {
  components: { Promo, Specifications },
  
}
</script>

<style>

</style>