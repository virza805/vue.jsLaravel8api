<template>
    <h1 style="color:#fff;"> Hello </h1>
</template>

<script>
    export default {
        name: 'Home'
    }
</script>

<style>

</style>

